# DealJoy 全栈代码生成项目

## 项目概述
DealJoy 是一个本地生活团购平台（类似美团/Groupon），目标市场为北美 Dallas 地区。
核心差异化：**"随时买，随时退"** — 无条件即时退款。

## 技术栈
- **前端**: Flutter 3.x + Dart 3.x, Riverpod 2.x, go_router, Material Design 3
- **后端**: Supabase (PostgreSQL 15+, Edge Functions/Deno, Auth, Storage, Realtime)
- **支付**: Stripe
- **推送**: Firebase Cloud Messaging

## 需求清单
需求来源文件: `requirements/DealJoy_V1_详细需求清单_v3.xlsx`
- 用户端 App: 18个功能系统, 682行需求
- 商家端: 13个功能系统
- 运营端: 13个功能系统
- 非功能需求: 性能/安全/合规/兼容性

## Agent 流水线架构
本项目通过6个专业子代理（sub-agents）自动生成代码：

```
需求Excel → [需求解析器] → [架构师] → [后端开发] → [前端开发] → [代码审查] → [测试工程师]
```

每个 Agent 是独立的 Claude Code 子代理，Pixel Agents 可实时可视化。

## 代码规范
- **语言规则**: 前端代码除注释外全部英文（UI文案、变量名、字符串、错误提示等），注释用中文
- **后端注释**: 中文
- **代码风格**: 遵循 Dart/TypeScript 官方风格指南
- **文件结构**: Feature-First (`lib/features/{module}/pages|widgets|providers|services/`)
- **状态管理**: Riverpod AsyncNotifier 模式
- **数据库**: 每张表必须有 RLS 策略，默认拒绝所有

## 输出目录结构
```
output/{模块名}/
├── 01_requirements.json      # 需求解析器输出
├── 02_architecture.json      # 架构师输出
├── 03_backend/               # 后端开发输出
│   ├── migrations/*.sql
│   ├── functions/**/*.ts
│   └── policies/*.sql
├── 04_frontend/              # 前端开发输出
│   └── lib/features/{module}/**/*.dart
├── 05_review.json            # 代码审查输出
└── 06_tests/                 # 测试工程师输出
```

## 当前试点模块
**1.用户认证系统** — 包含注册、登录、第三方OAuth、密码重置、邮箱验证、Token管理
